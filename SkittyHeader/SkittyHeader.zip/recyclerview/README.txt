Library Project including RecyclerView and associated utilities.
